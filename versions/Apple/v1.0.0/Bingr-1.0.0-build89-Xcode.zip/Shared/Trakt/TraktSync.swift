import Foundation
import Combine

/// Houdt bij wat er bekeken is (2 kanten op):
/// - haalt bekeken films/afleveringen, voortgang en watchlist van Trakt → vinkjes in de app
/// - afvinken in de app of uitkijken in de player → naar Trakt (history + scrobble)
@MainActor
final class TraktSync: ObservableObject {
    static let shared = TraktSync()

    @Published private(set) var isLoggedIn = false
    @Published private(set) var username: String?
    @Published private(set) var watchedMovies: Set<String> = []                 // imdb
    @Published private(set) var watchedEpisodes: [String: Set<String>] = [:]    // show-imdb → "s-e"
    @Published private(set) var watchlist: Set<String> = []                     // imdb
    @Published private(set) var playback: [PlaybackItem] = []
    @Published private(set) var lastRefresh: Date?
    /// Bezig met synchroniseren (draaiende pijltjes in Mijn Bingr)
    @Published private(set) var isSyncing = false
    /// Kort zichtbaar na een geslaagde sync ("Bijgewerkt ✓")
    @Published private(set) var justSynced = false
    /// Laatste melding over doorgeven aan Trakt ("Gezien op Trakt: …")
    @Published private(set) var lastScrobble: String?
    @Published private(set) var lastScrobbleDate: Date?
    @Published var lastError: String?
    @Published private(set) var displayName: String?
    @Published private(set) var avatar: URL?

    static var scrobbleEnabled: Bool { UserDefaults.standard.object(forKey: "trakt.scrobble") as? Bool ?? true }
    static var askRating: Bool { UserDefaults.standard.object(forKey: "trakt.askRating") as? Bool ?? true }
    /// Titel(+jaar) → IMDb-ID, zodat vinkjes direct op IPTV-titels passen zonder per titel op te zoeken.
    @Published private(set) var titleIndex = TitleIndex()

    struct TitleIndex: Codable {
        var movies: [String: String] = [:]
        var shows: [String: String] = [:]
        /// TMDB-id → IMDb-id (build 75): veel IPTV-servers geven het TMDB-id mee, dat past beter dan de titel
        var tmdbMovies: [Int: String] = [:]
        var tmdbShows: [Int: String] = [:]
        /// IMDb-id → jaar, om bij een titel zonder jaar-treffer geen remake/andere serie met dezelfde naam af te vinken
        var years: [String: Int] = [:]

        init() {}
        private enum K: String, CodingKey { case movies, shows, tmdbMovies, tmdbShows, years }
        init(from decoder: Decoder) throws {
            let c = try decoder.container(keyedBy: K.self)
            movies = (try? c.decodeIfPresent([String: String].self, forKey: .movies)) ?? [:]
            shows = (try? c.decodeIfPresent([String: String].self, forKey: .shows)) ?? [:]
            tmdbMovies = (try? c.decodeIfPresent([Int: String].self, forKey: .tmdbMovies)) ?? [:]
            tmdbShows = (try? c.decodeIfPresent([Int: String].self, forKey: .tmdbShows)) ?? [:]
            years = (try? c.decodeIfPresent([String: Int].self, forKey: .years)) ?? [:]
        }

        static func norm(_ t: String) -> String {
            t.folding(options: [.diacriticInsensitive, .caseInsensitive], locale: nil)
             .filter { $0.isLetter || $0.isNumber }
        }
        mutating func add(title: String?, year: Int?, imdb: String, show: Bool, tmdb: Int? = nil) {
            if let tmdb, tmdb > 0 { if show { tmdbShows[tmdb] = imdb } else { tmdbMovies[tmdb] = imdb } }
            if let year { years[imdb] = year }
            guard let title else { return }
            let n = Self.norm(title)
            guard !n.isEmpty else { return }
            if show { shows[n] = imdb; if let year { shows["\(n)|\(year)"] = imdb } }
            else { movies[n] = imdb; if let year { movies["\(n)|\(year)"] = imdb } }
        }
        func imdb(tmdb: Int?, show: Bool) -> String? {
            guard let tmdb, tmdb > 0 else { return nil }
            return show ? tmdbShows[tmdb] : tmdbMovies[tmdb]
        }
        func imdb(title: String, year: Int?, show: Bool) -> String? {
            let n = Self.norm(title), d = show ? shows : movies
            guard !n.isEmpty else { return nil }
            guard let year else { return d[n] }
            // jaar klopt (of scheelt één jaar: release in het ene land, première in het andere)
            if let i = d["\(n)|\(year)"] ?? d["\(n)|\(year - 1)"] ?? d["\(n)|\(year + 1)"] { return i }
            // alleen op titel als het jaar van die treffer onbekend is of past: "The Office" (2001) ≠ "The Office" (2005)
            guard let i = d[n] else { return nil }
            if let y = years[i], abs(y - year) > 1 { return nil }
            return i
        }
    }

    /// IMDb-ID van een IPTV-titel: eerst uit de Trakt-index, dan uit de metadata-cache.
    /// Ook de schone titel proberen ("NL | Reacher (2022) 4K" → "Reacher", 2022), anders vinden we je Trakt-vinkjes niet.
    /// Volgorde (build 75): IMDb-id van de bron → TMDB-id (van de bron of uit de details) → titel+jaar uit je Trakt-geschiedenis
    /// (een titel met een ander jaar telt niet) → IMDb-id uit de metadata (OMDb/TMDB).
    func imdb(for m: Movie) -> String? {
        m.imdbID ?? titleIndex.imdb(tmdb: m.tmdbID ?? knownTMDb(m.id), show: false)
            ?? indexed(m.title, m.year, show: false) ?? MetadataService.shared.cached(m)?.imdbID
    }
    func imdb(for s: Series) -> String? {
        s.imdbID ?? titleIndex.imdb(tmdb: s.tmdbID ?? knownTMDb(s.id), show: true)
            ?? indexed(s.title, s.year, show: true) ?? MetadataService.shared.cached(s)?.imdbID
    }
    /// TMDB-id dat Bingr eerder bij de details van deze titel vond (ContentLanguage.Facts, build 59)
    private func knownTMDb(_ id: String) -> Int? {
        titleIndex.tmdbMovies.isEmpty && titleIndex.tmdbShows.isEmpty ? nil : ContentLanguage.Facts.shared.tmdbID(id)
    }
    private func indexed(_ raw: String, _ year: Int?, show: Bool) -> String? {
        // niets in de index (niet ingelogd / subprofiel)? dan ook niet elke titel opschonen — scheelt veel rekenwerk bij scrollen
        guard !(show ? titleIndex.shows.isEmpty : titleIndex.movies.isEmpty) else { return nil }
        let c = cleaned(raw)
        let y = year ?? c.year
        if let i = titleIndex.imdb(title: raw, year: y, show: show) { return i }
        return titleIndex.imdb(title: c.title, year: y, show: show)
    }
    private var cleanCache: [String: (title: String, year: Int?)] = [:]
    private func cleaned(_ raw: String) -> (title: String, year: Int?) {
        if let c = cleanCache[raw] { return c }
        let p = TitleCleaner.parse(raw)
        let c = (title: p.title, year: p.year)
        if cleanCache.count > 20_000 { cleanCache.removeAll() }
        cleanCache[raw] = c
        return c
    }

    /// IMDb-ID opzoeken bij Trakt als de titel er nog geen heeft (zodat kijken toch als "gezien" wordt doorgegeven).
    private func resolveIMDb(_ item: PlayableItem) async -> String? {
        if let i = item.imdbID { return i }
        let show = item.type == .episode
        let c = cleaned(item.title)
        if let i = titleIndex.imdb(title: item.title, year: nil, show: show) ?? titleIndex.imdb(title: c.title, year: c.year, show: show) {
            return i
        }
        let year = show ? c.year : (c.year ?? item.subtitle.flatMap { Int($0) })
        guard let hit = await lookup(title: c.title, year: year, isShow: show), let i = hit.ids.imdb else { return nil }
        titleIndex.add(title: item.title, year: nil, imdb: i, show: show)
        titleIndex.add(title: hit.title, year: hit.year, imdb: i, show: show)
        saveCache()
        return i
    }

    private let client = TraktClient.shared
    private var lastActivity: String?

    struct PlaybackItem: Identifiable, Hashable {
        var id: Int
        var progress: Double      // 0..100
        var type: String          // movie / episode
        var imdb: String?         // film of serie
        var title: String
        var season: Int?
        var episode: Int?
    }

    private init() {
        Task { await bootstrap() }
    }

    /// Trakt hoort bij het hoofdaccount: andere profielen zien geen Trakt-vinkjes, -voortgang of -aanbevelingen
    /// en scrobblen niet naar het Trakt-account van het hoofdaccount.
    private var profileAllowed = true

    func applyProfile(isMain: Bool) async {
        profileAllowed = isMain
        if isMain {
            let loggedIn = await client.isLoggedIn
            let name = await client.tokens?.username
            // intussen naar een ander profiel gewisseld? dan niets van Trakt laten zien
            guard profileAllowed else { return }
            isLoggedIn = loggedIn
            username = name
            loadCache()
            if isLoggedIn { await refresh() }
        } else {
            isLoggedIn = false
            watchedMovies = []; watchedEpisodes = [:]; watchlist = []; playback = []
        }
    }

    func bootstrap() async {
        profileAllowed = CloudStore.shared.isMainActive || CloudStore.shared.profiles.count <= 1
        guard profileAllowed else { return }
        let loggedIn = await client.isLoggedIn
        let name = await client.tokens?.username
        guard profileAllowed else { return }   // tijdens het opstarten al een ander profiel gekozen
        isLoggedIn = loggedIn
        username = name
        loadCache()
        if isLoggedIn { await refresh(); await loadProfile() }
    }

    // MARK: inloggen

    func startLogin() async throws -> TraktDeviceCode { try await client.startDeviceLogin() }

    func finishLogin(_ code: TraktDeviceCode) async throws {
        let t = try await client.pollForToken(code)
        isLoggedIn = true; username = t.username
        await refresh(force: true)
        await loadProfile()
    }

    /// Trakt-koppeling uit de Bingr-account toegepast (StateSync): de UI meteen bijwerken.
    /// `tokens` nil = elders uitgelogd (lokaal wissen, zonder intrekken bij Trakt).
    func applySyncedConnection(_ tokens: TraktTokens?) async {
        await client.store(tokens)
        guard tokens != nil else {
            isLoggedIn = false; username = nil
            watchedMovies = []; watchedEpisodes = [:]; watchlist = []; playback = []; titleIndex = TitleIndex()
            displayName = nil; avatar = nil
            saveCache()
            return
        }
        let wasLoggedIn = isLoggedIn
        username = tokens?.username ?? username
        // andere profielen dan het hoofdaccount zien Trakt niet (zie applyProfile)
        guard profileAllowed else { return }
        isLoggedIn = true
        if !wasLoggedIn {
            loadCache()
            // los starten: dit kan vanuit een Trakt-verversing komen (zie StateSync.beforeTraktRefresh)
            Task { @MainActor in
                await self.refresh(force: true)
                await self.loadProfile()
            }
        }
    }

    func logout() async {
        await client.logout()
        isLoggedIn = false; username = nil
        watchedMovies = []; watchedEpisodes = [:]; watchlist = []; playback = []; titleIndex = TitleIndex()
        saveCache()
    }

    // MARK: ophalen

    private struct LastActivities: Decodable { let all: String? }
    private struct WatchedMovie: Decodable { struct M: Decodable { let title: String?; let year: Int?; let ids: TraktIDs }; let movie: M }
    private struct WatchedShow: Decodable {
        struct S: Decodable { let title: String?; let year: Int?; let ids: TraktIDs }
        struct Season: Decodable { struct E: Decodable { let number: Int }; let number: Int; let episodes: [E] }
        let show: S; let seasons: [Season]?
    }
    private struct Playback: Decodable {
        struct Media: Decodable { let title: String?; let ids: TraktIDs; let season: Int?; let number: Int? }
        let id: Int; let progress: Double; let type: String
        let movie: Media?; let episode: Media?; let show: Media?
    }
    private struct WatchlistItem: Decodable {
        struct Media: Decodable { let title: String?; let year: Int?; let ids: TraktIDs }
        let movie: Media?; let show: Media?
    }

    func refresh(force: Bool = false) async {
        guard isLoggedIn else {
            if force { lastError = L("Not signed in to Trakt.") }
            return
        }
        // build 88: Trakt hoort bij Lifetime; op een Gratis-account staat synchroniseren stil
        guard EntitlementsService.shared.allows(.trakt) else { return }
        guard !isSyncing else { return }
        isSyncing = true
        let started = Date()
        defer {
            // spinner minstens even laten zien, en daarna kort "Bijgewerkt ✓"
            let wait = max(0, 0.9 - Date().timeIntervalSince(started))
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: UInt64(wait * 1_000_000_000))
                self.isSyncing = false
                if self.lastError == nil {
                    self.justSynced = true
                    try? await Task.sleep(nanoseconds: 2_500_000_000)
                    self.justSynced = false
                }
            }
        }
        do {
            let act: LastActivities = try await client.get("/sync/last_activities")
            if !force, let a = act.all, a == lastActivity, !watchedMovies.isEmpty || !watchedEpisodes.isEmpty {
                lastRefresh = Date(); return
            }
            async let m: [WatchedMovie] = client.get("/sync/watched/movies")
            async let s: [WatchedShow] = client.get("/sync/watched/shows")
            async let p: [Playback] = client.get("/sync/playback")
            async let w: [WatchlistItem] = client.get("/sync/watchlist")

            let movies = try await m
            let shows = try await s
            let pb = try await p
            let wl = try await w
            // intussen naar een ander profiel gewisseld of uitgelogd? dan de vinkjes van het hoofdaccount niet tonen
            guard profileAllowed, isLoggedIn else { return }
            watchedMovies = Set(movies.compactMap { $0.movie.ids.imdb })
            var tIndex = titleIndex
            for x in movies {
                if let i = x.movie.ids.imdb { tIndex.add(title: x.movie.title, year: x.movie.year, imdb: i, show: false, tmdb: x.movie.ids.tmdb) }
            }
            var eps: [String: Set<String>] = [:]
            for show in shows {
                guard let imdb = show.show.ids.imdb else { continue }
                tIndex.add(title: show.show.title, year: show.show.year, imdb: imdb, show: true, tmdb: show.show.ids.tmdb)
                var set = Set<String>()
                for season in show.seasons ?? [] { for e in season.episodes { set.insert("\(season.number)-\(e.number)") } }
                eps[imdb] = set
            }
            watchedEpisodes = eps
            playback = pb.map { x -> PlaybackItem in
                if x.type == "episode" {
                    return PlaybackItem(id: x.id, progress: x.progress, type: x.type, imdb: x.show?.ids.imdb,
                                        title: x.show?.title ?? "", season: x.episode?.season, episode: x.episode?.number)
                }
                return PlaybackItem(id: x.id, progress: x.progress, type: x.type, imdb: x.movie?.ids.imdb, title: x.movie?.title ?? "")
            }
            watchlist = Set(wl.compactMap { $0.movie?.ids.imdb ?? $0.show?.ids.imdb })
            for x in wl {
                if let mm = x.movie, let i = mm.ids.imdb { tIndex.add(title: mm.title, year: mm.year, imdb: i, show: false, tmdb: mm.ids.tmdb) }
                if let ss = x.show, let i = ss.ids.imdb { tIndex.add(title: ss.title, year: ss.year, imdb: i, show: true, tmdb: ss.ids.tmdb) }
            }
            titleIndex = tIndex
            lastActivity = act.all
            lastRefresh = Date()
            lastError = nil
            saveCache()
        } catch {
            lastError = error.localizedDescription
            if case TraktError.notLoggedIn = error { isLoggedIn = false }
        }
    }

    // MARK: status in de UI

    func isWatched(movie imdb: String?) -> Bool {
        guard let imdb else { return false }; return watchedMovies.contains(imdb)
    }
    func isWatched(show imdb: String?, season: Int, episode: Int) -> Bool {
        guard let imdb else { return false }; return watchedEpisodes[imdb]?.contains("\(season)-\(episode)") ?? false
    }
    func watchedCount(show imdb: String?) -> Int { imdb.flatMap { watchedEpisodes[$0]?.count } ?? 0 }
    /// Bekeken afleveringen ("seizoen-aflevering") van een serie op Trakt.
    func watchedEpisodeKeys(show imdb: String?) -> Set<String> { imdb.flatMap { watchedEpisodes[$0] } ?? [] }

    func playbackProgress(movie imdb: String?) -> Double? {
        guard let imdb else { return nil }
        return playback.first { $0.type == "movie" && $0.imdb == imdb }.map { $0.progress / 100 }
    }

    // MARK: schrijven

    func setWatched(_ item: PlayableItem, _ watched: Bool) async {
        guard isLoggedIn, let imdb = await resolveIMDb(item) else { return }
        let body: [String: Any]
        if item.type == .episode, let s = item.season, let e = item.episode {
            body = ["shows": [["ids": ["imdb": imdb], "seasons": [["number": s, "episodes": [["number": e]]]]]]]
            var set = watchedEpisodes[imdb] ?? []
            if watched { set.insert("\(s)-\(e)") } else { set.remove("\(s)-\(e)") }
            watchedEpisodes[imdb] = set
        } else {
            body = ["movies": [["ids": ["imdb": imdb]]]]
            if watched { watchedMovies.insert(imdb) } else { watchedMovies.remove(imdb) }
        }
        saveCache()
        do { try await client.postRaw(watched ? "/sync/history" : "/sync/history/remove", body: body) }
        catch { lastError = error.localizedDescription }
    }

    /// Hele seizoen of serie in één keer afvinken.
    func setWatched(show imdb: String, episodes: [Episode], _ watched: Bool) async {
        guard isLoggedIn else { return }
        let bySeason = Dictionary(grouping: episodes, by: \.season)
        let seasons = bySeason.map { s, eps in ["number": s, "episodes": eps.map { ["number": $0.number] }] as [String: Any] }
        var set = watchedEpisodes[imdb] ?? []
        for e in episodes { if watched { set.insert("\(e.season)-\(e.number)") } else { set.remove("\(e.season)-\(e.number)") } }
        watchedEpisodes[imdb] = set
        saveCache()
        do { try await client.postRaw(watched ? "/sync/history" : "/sync/history/remove",
                                      body: ["shows": [["ids": ["imdb": imdb], "seasons": seasons]]]) }
        catch { lastError = error.localizedDescription }
    }

    /// Zet een titel op of van de Trakt-watchlist (spiegelt Mijn lijst van het hoofdaccount).
    func setWatchlist(imdb: String, isShow: Bool, _ on: Bool) async {
        guard isLoggedIn, watchlist.contains(imdb) != on else { return }
        await toggleWatchlist(imdb: imdb, isShow: isShow)
    }

    func toggleWatchlist(imdb: String, isShow: Bool) async {
        guard isLoggedIn else { return }
        let add = !watchlist.contains(imdb)
        if add { watchlist.insert(imdb) } else { watchlist.remove(imdb) }
        let body: [String: Any] = [isShow ? "shows" : "movies": [["ids": ["imdb": imdb]]]]
        do { try await client.postRaw(add ? "/sync/watchlist" : "/sync/watchlist/remove", body: body) }
        catch { lastError = error.localizedDescription }
    }

    enum ScrobbleAction: String { case start, pause, stop }

    /// Scrobble: Trakt markeert automatisch als bekeken bij stop ≥ 80%.
    /// Uitkomst van een scrobble (voor een melding in de speler en de status in Mijn Bingr).
    enum ScrobbleResult { case ok, notFound, failed, skipped }

    @discardableResult
    func scrobble(_ action: ScrobbleAction, item: PlayableItem, progress: Double) async -> ScrobbleResult {
        guard isLoggedIn, Self.scrobbleEnabled, item.type != .live, EntitlementsService.shared.allows(.trakt) else { return .skipped }
        guard let imdb = await resolveIMDb(item) else {
            lastScrobble = L("Not found on Trakt: %@", item.title)
            return .notFound
        }
        let isEpisode = item.type == .episode && item.season != nil && item.episode != nil
        var body: [String: Any] = ["progress": min(max(progress * 100, 0), 100), "app_version": "1.0.0"]
        if isEpisode, let s = item.season, let e = item.episode {
            body["show"] = ["ids": ["imdb": imdb]]
            body["episode"] = ["season": s, "number": e]
        } else {
            body["movie"] = ["ids": ["imdb": imdb]]
        }
        let name = isEpisode ? "\(item.title) S\(item.season ?? 0)E\(item.episode ?? 0)" : item.title
        var result: ScrobbleResult = .ok
        do {
            try await client.postRaw("/scrobble/\(action.rawValue)", body: body)
        } catch {
            result = .failed
            lastError = error.localizedDescription
        }
        let watched = action == .stop && progress >= 0.8
        if watched {
            // scrobble mislukt? dan direct in je Trakt-geschiedenis zetten, zodat het toch als gezien staat
            if result == .failed {
                let hist: [String: Any] = isEpisode
                    ? ["shows": [["ids": ["imdb": imdb], "seasons": [["number": item.season ?? 0, "episodes": [["number": item.episode ?? 0]]]]]]]
                    : ["movies": [["ids": ["imdb": imdb]]]]
                if (try? await client.postRaw("/sync/history", body: hist)) != nil { result = .ok; lastError = nil }
            }
            if result == .ok {
                if isEpisode, let s = item.season, let e = item.episode { watchedEpisodes[imdb, default: []].insert("\(s)-\(e)") }
                else { watchedMovies.insert(imdb) }
                saveCache()
            }
        }
        switch (action, result) {
        case (_, .failed): lastScrobble = L("Could not reach Trakt for %@", name)
        case (.stop, .ok): lastScrobble = watched ? L("Marked as watched on Trakt: %@", name) : L("Progress saved on Trakt: %@", name)
        case (.start, .ok): lastScrobble = L("Watching on Trakt: %@", name)
        default: break
        }
        lastScrobbleDate = Date()
        // na het kijken de vinkjes van Trakt ophalen (ook wat je intussen elders keek)
        if action == .stop {
            try? await Task.sleep(nanoseconds: 3_000_000_000)
            await refresh(force: true)
        }
        return result
    }

    // MARK: metadata via Trakt (IMDb-id en trailer)

    struct TraktMedia: Decodable { let title: String?; let year: Int?; let ids: TraktIDs; let trailer: String? }
    private struct SearchHit: Decodable { let type: String; let movie: TraktMedia?; let show: TraktMedia? }

    func lookup(title: String, year: Int?, isShow: Bool) async -> TraktMedia? {
        guard Secrets.isSet(Secrets.traktClientID) else { return nil }
        var q = ["query": title, "extended": "full", "limit": "5"]
        if let year { q["years"] = String(year) }
        let hits: [SearchHit]? = try? await client.get("/search/\(isShow ? "show" : "movie")", query: q, auth: false)
        if let h = hits?.first { return h.movie ?? h.show }
        if year != nil { return await lookup(title: title, year: nil, isShow: isShow) }
        return nil
    }

    func lookup(imdb: String) async -> TraktMedia? {
        let hits: [SearchHit]? = try? await client.get("/search/imdb/\(imdb)", query: ["extended": "full"], auth: false)
        return hits?.first.flatMap { $0.movie ?? $0.show }
    }

    /// Profiel (naam + avatar) voor het Trakt-scherm.
    func loadProfile() async {
        struct S: Decodable {
            struct U: Decodable {
                struct Img: Decodable { struct A: Decodable { let full: String? }; let avatar: A? }
                let username: String?; let name: String?; let images: Img?
            }
            let user: U?
        }
        guard isLoggedIn, let s: S = try? await client.get("/users/settings", query: ["extended": "full"]) else { return }
        displayName = s.user?.name.flatMap { $0.isEmpty ? nil : $0 } ?? s.user?.username
        username = s.user?.username ?? username
        avatar = s.user?.images?.avatar?.full.flatMap(URL.init(string:))
    }

    /// Waardering 1–10 naar Trakt sturen.
    func rate(_ item: PlayableItem, _ rating: Int) async {
        guard isLoggedIn, let imdb = item.imdbID else { return }
        let body: [String: Any]
        if item.type == .episode, let s = item.season, let e = item.episode {
            body = ["shows": [["ids": ["imdb": imdb], "seasons": [["number": s, "episodes": [["number": e, "rating": rating]]]]]]]
        } else {
            body = ["movies": [["ids": ["imdb": imdb], "rating": rating]]]
        }
        _ = try? await client.postRaw("/sync/ratings", body: body)
    }

    /// Verwijder een half-gekeken item uit Trakt's "verder kijken".
    func removePlayback(_ id: Int) async {
        playback.removeAll { $0.id == id }
        try? await client.delete("/sync/playback/\(id)")
    }

    /// Titels die lijken op een film/serie (werkt ook zonder inloggen).
    func related(imdb: String, shows: Bool) async -> [TraktMedia] {
        guard Secrets.isSet(Secrets.traktClientID) else { return [] }
        let r: [TraktMedia]? = try? await client.get("/\(shows ? "shows" : "movies")/\(imdb)/related",
                                                      query: ["limit": "20"], auth: false)
        return r ?? []
    }

    /// Persoonlijke aanbevelingen van Trakt (alleen ingelogd).
    func recommendations(shows: Bool) async -> [TraktMedia] {
        guard isLoggedIn else { return [] }
        let r: [TraktMedia]? = try? await client.get(shows ? "/recommendations/shows" : "/recommendations/movies",
                                                      query: ["limit": "50", "ignore_collected": "false"])
        return r ?? []
    }

    struct TrendingEntry: Decodable { let movie: TraktMedia?; let show: TraktMedia? }
    func trending(shows: Bool) async -> [TraktMedia] {
        let r: [TrendingEntry]? = try? await client.get(shows ? "/shows/trending" : "/movies/trending",
                                                         query: ["limit": "100"], auth: false)
        return r?.compactMap { $0.movie ?? $0.show } ?? []
    }

    // MARK: cache (zodat vinkjes direct zichtbaar zijn bij opstarten)

    /// `v`: versie van de cache; bij een oudere versie alles opnieuw ophalen (build 75: TMDB-ids en jaren in de index)
    private struct Cache: Codable { var m: Set<String>; var e: [String: Set<String>]; var w: Set<String>; var a: String?; var t: TitleIndex?; var v: Int? }
    private static let cacheVersion = 2
    private var cacheURL: URL {
        FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)[0].appendingPathComponent("trakt-cache.json")
    }
    private func saveCache() {
        let c = Cache(m: watchedMovies, e: watchedEpisodes, w: watchlist, a: lastActivity, t: titleIndex, v: Self.cacheVersion)
        if let d = try? JSONEncoder().encode(c) { try? d.write(to: cacheURL) }
    }
    private func loadCache() {
        guard isLoggedIn, profileAllowed, let d = try? Data(contentsOf: cacheURL), let c = try? JSONDecoder().decode(Cache.self, from: d) else { return }
        watchedMovies = c.m; watchedEpisodes = c.e; watchlist = c.w; titleIndex = c.t ?? TitleIndex()
        // oude cache (zonder TMDB-ids/jaren): de volgende verversing niet overslaan
        lastActivity = c.v == Self.cacheVersion ? c.a : nil
    }
}
